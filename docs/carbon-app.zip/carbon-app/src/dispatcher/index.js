import { Dispatcher } from 'flux';

// initialize the dispatcher (a singleton for your application)
let AppDispatcher = new Dispatcher();

export default AppDispatcher;
